

using FaizMobileApp6.Models;
using System.Text;

namespace FaizMobileApp6
{
    public partial class ListOfContentPage : ContentPage
    {
        public ListOfContentPage()
        {
            InitializeComponent();
            lblPageTitle.Text = "Second Page";
            lblPageTitle1.Text = "Second Page";
        }

        private async void OnProceedClicked(object sender, EventArgs e)
        {
            await Shell.Current.Navigation.PushModalAsync(new NavigationPage(new DisplayContentPage()), false);
        }

        private void btnGoBack_Clicked(object sender, EventArgs e)
        {
            OnBackButtonPressed();
        }
        protected override bool OnBackButtonPressed()
        {
            Shell.Current.Navigation.PushAsync(new MainPage(), false);
            return true;
        }

    }
}

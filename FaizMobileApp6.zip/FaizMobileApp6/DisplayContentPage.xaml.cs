﻿
using CommunityToolkit.Maui.Views;
using FaizMobileApp6.Models;
using FaizMobileApp6.Views;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Dispatching;
using Microsoft.Maui.Controls.Platform;
using static System.Net.Mime.MediaTypeNames;
using CommunityToolkit.Maui.Alerts;
using System.Diagnostics;
using Microsoft.Maui.Controls.PlatformConfiguration;
using Microsoft.Maui.Handlers;

namespace FaizMobileApp6
{
    public partial class DisplayContentPage : TabbedPage
    {
        public int _TotalTabCount;
        public int _SelectedTabnumber;
        DisplayContentRepository objDisplayContentRepository = new DisplayContentRepository();
        private bool isProcessingPageChange = false;

        public DisplayContentPage(int GotoTabnumber = 1)
        {
            InitializeComponent();
            _SelectedTabnumber = GotoTabnumber;
            LoadInitialData();

        }
        public async void LoadInitialData()
        {
            _TotalTabCount = await objDisplayContentRepository.GetTotalTabCount();

            if (_TotalTabCount > 0)
            {
                if (_SelectedTabnumber > _TotalTabCount)
                {
                    _SelectedTabnumber = _TotalTabCount;
                }
                DisplaycontentPageID.ItemsSource = await objDisplayContentRepository.GetListOfContent(_SelectedTabnumber);
                if (Children.Count > 1)
                {
                    if (_TotalTabCount != _SelectedTabnumber)
                    {
                        CurrentPage = Children[1]; // Set the second tab as selected
                    }
                    CurrentPageChanged += OnCurrentPageChanged1;
                }
            }
        }

        protected async void CurrentPageHasChanged1(object sender, EventArgs e)
        {
            var tabbedPage = (TabbedPage)sender;
            DisplayContent _DisplayContent = (DisplayContent)tabbedPage.SelectedItem;
            await Navigation.PushModalAsync(new DisplayContentPage(_DisplayContent.TabNumber), false);
        }


        private async void OnCurrentPageChanged1(object sender, EventArgs e)
        {
            // Prevent multiple triggers
            if (isProcessingPageChange) return;
            try
            {
                this.CurrentPageChanged -= OnCurrentPageChanged1;
                var tabbedPage = (TabbedPage)sender;
                DisplayContent _DisplayContent = (DisplayContent)tabbedPage.SelectedItem;

                if (CurrentPage != null)
                {
                    isProcessingPageChange = true;
                    // Defer the execution to the next UI cycle
                    await Dispatcher.DispatchAsync(async () =>
                    {
                        if (isProcessingPageChange == true)
                        {
                            DisplaycontentPageID.ItemsSource = await objDisplayContentRepository.GetListOfContent(_DisplayContent.TabNumber);
                            this.Handler.SetVirtualView(this);

                            MainThread.BeginInvokeOnMainThread(() =>
                            {
                                try
                                {
                                    if (Children.Count > 1)
                                    {
                                        if (_TotalTabCount != _DisplayContent.TabNumber)
                                        {
                                            CurrentPage = Children[1]; // Set the second tab as selected
                                            this.Handler.SetVirtualView(this);
                                        }
                                    }
                                }
                                catch (ArgumentOutOfRangeException ex)
                                {

                                }
                            });
                            isProcessingPageChange = false;
                        }
                    });
                }
            }
            catch
            {
            }
            finally
            {
                isProcessingPageChange = false;
                this.CurrentPageChanged += OnCurrentPageChanged1;
            }
        }

        private async void btnGoToTab_Clicked(object sender, EventArgs e)
        {
            var Popup = new GoToTabPopupView();
            var result = await this.ShowPopupAsync(Popup);
            int gototab = (int)(result ?? 0);
            if (gototab != 0)
                await Shell.Current.Navigation.PushModalAsync(new DisplayContentPage(gototab), false);
        }

        private void btnShowFullContent_Clicked(object sender, EventArgs e)
        {
            Navigation.PushModalAsync(new NavigationPage(new DisplayFullContentPage()), false);
        }

        private void btnGoBack_Clicked(object sender, EventArgs e)
        {
            OnBackButtonPressed();
        }
        protected override bool OnBackButtonPressed()
        {
            Shell.Current.Navigation.PushAsync(new ListOfContentPage(), false);
            return true;
        }
    }
}
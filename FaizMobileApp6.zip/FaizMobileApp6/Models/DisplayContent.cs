﻿

namespace FaizMobileApp6.Models
{
    public class DisplayContent
    {
        public int TabNumber { get; set; }
        public string? Description { get; set; }
        public string? TitleText { get; set; }

    }
}

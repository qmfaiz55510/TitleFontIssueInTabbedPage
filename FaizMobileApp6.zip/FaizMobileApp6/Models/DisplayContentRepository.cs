﻿

namespace FaizMobileApp6.Models
{
    public class DisplayContentRepository
    {
        private static readonly List<DisplayContent> _DisplayPageContent =
        [
            new (){ TabNumber=1,TitleText="1 الفاتحة",Description="Tab 1" },
            new (){ TabNumber=2,TitleText="2 الفاتحة",Description="Tab 2" },
            new (){ TabNumber=3,TitleText="3 الفاتحة",Description="Tab 3" },
            new (){ TabNumber=4,TitleText="4 الفاتحة",Description="Tab 4" },
            new (){ TabNumber=5,TitleText="5 الفاتحة",Description="Tab 5" },
            new (){ TabNumber=6,TitleText="6 الفاتحة",Description="Tab 6" },
            new (){ TabNumber=7,TitleText="7 الفاتحة",Description="Tab 7" },
        ];

        public async Task<int> GetTotalTabCount()
        {
            await Task.Delay(0);
            return _DisplayPageContent.Count;
        }
        public async Task<List<DisplayContent>> GetListOfContent(int SelectedTabnumber)
        {
            if (SelectedTabnumber == 0)
                SelectedTabnumber = 1;
            int DisplayTabCount = (SelectedTabnumber == 1 ? 2 : 3);
            int? StartAyatfrom = (SelectedTabnumber > 1) ? (SelectedTabnumber - 1) : SelectedTabnumber;
            List<DisplayContent> _ContentByLanguage;
            _ContentByLanguage = _DisplayPageContent.FindAll(x => x.TabNumber >= StartAyatfrom).OrderBy(x => x.TabNumber).Take(DisplayTabCount).ToList<DisplayContent>();
            await Task.Delay(0);
            return _ContentByLanguage.OrderByDescending(x => x.TabNumber).ToList<DisplayContent>();
        }
    }
}

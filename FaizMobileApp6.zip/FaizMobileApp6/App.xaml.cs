﻿using FaizMobileApp6.Models;
using Microsoft.Maui.Platform;

namespace FaizMobileApp6
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            MainPage = new AppShell();
        }
    }
}

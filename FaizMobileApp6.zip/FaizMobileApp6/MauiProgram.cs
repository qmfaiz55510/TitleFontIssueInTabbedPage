﻿
using CommunityToolkit.Maui;
using FaizMobileApp6.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Handlers;
using System.Reflection;

namespace FaizMobileApp6
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();

            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                    fonts.AddFont("alqalamquranmajeedwebregular.ttf", "AlQalamnew");
                })
            .ConfigureMauiHandlers(handlers =>
            {
#if ANDROID
                    // Add a handler
                    handlers.AddHandler(typeof(TabbedPage), typeof(FaizMobileApp6.Platforms.Android.MyTabbedViewHandler));
#endif
            });

            return builder.Build();


        }
    }


}




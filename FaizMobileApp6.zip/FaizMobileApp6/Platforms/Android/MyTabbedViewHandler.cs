﻿
using Android.Widget;
using AndroidX.Fragment.App;
using Google.Android.Material.Tabs;
using Microsoft.Maui.Controls.Compatibility.Platform.Android;
using Microsoft.Maui.Handlers;
using System.Reflection;

namespace FaizMobileApp6.Platforms.Android
{
    public class MyTabbedViewHandler : TabbedViewHandler
    {
        public override void SetVirtualView(IView view)
        {
            base.SetVirtualView(view);

            SetTabFont(view);
        }
        public override void UpdateValue(string property)
        {
            base.UpdateValue(property);
            try
            {
                var tabs = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity?.FindViewById<FragmentContainerView>(Microsoft.Maui.Resource.Id
                .navigationlayout_toptabs);
                var tabLayout = tabs?.GetChildAt(0);
                if (tabLayout is TabLayout layout)
                {
                    for (int i = 0; i < layout.TabCount; i++)
                    {
                        TabLayout.Tab? tab = layout.GetTabAt(i);
                        TabLayout.TabView? view1 = tab?.View;

                        for (int j = 0; j < (view1?.ChildCount ?? 0); j++)
                        {
                            var child = view1?.GetChildAt(j);

                            if (child is TextView tv)
                            {
                                tv.Typeface = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity.Resources.GetFont(Resource.Raw.alqalamquranmajeedwebregular);
                            }
                        }
                    }
                }
            }
            catch { }
        }
        
        public bool SetTabFont(IView view)
        {
            try
            {
                FieldInfo tabbedPageManagerFieldInfo = typeof(TabbedPage).GetField("_tabbedPageManager", BindingFlags.NonPublic | BindingFlags.Instance);
                object tabbedPageManager = tabbedPageManagerFieldInfo?.GetValue(view);

                FieldInfo tabLayoutFieldInfo = tabbedPageManager?.GetType().GetField("_tabLayout", BindingFlags.NonPublic | BindingFlags.Instance);
                TabLayout tabLayout = tabLayoutFieldInfo?.GetValue(tabbedPageManager) as TabLayout;

                if (tabLayout != null)
                {
                    for (int i = 0; i < tabLayout.TabCount; i++)
                    {
                        TabLayout.Tab? tab = tabLayout.GetTabAt(i);
                        TabLayout.TabView? view1 = tab?.View;

                        for (int j = 0; j < (view1?.ChildCount ?? 0); j++)
                        {
                            var child = view1?.GetChildAt(j);

                            if (child is TextView tv)
                            {
                                tv.Typeface = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity.Resources.GetFont(Resource.Raw.alqalamquranmajeedwebregular);
                            }
                        }
                    }
                    
                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}

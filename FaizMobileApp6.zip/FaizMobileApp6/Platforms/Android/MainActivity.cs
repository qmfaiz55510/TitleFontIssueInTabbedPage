﻿using Android.App;
using Android.Content.PM;
using Android.Media;
using Android.OS;
using Android.Widget;
using System.Linq;
using static Microsoft.Maui.LifecycleEvents.AndroidLifecycle;

namespace FaizMobileApp6
{
    [Activity(Theme = "@style/Maui.SplashTheme", MainLauncher = true, LaunchMode = LaunchMode.SingleTop, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density)]
    public class MainActivity : MauiAppCompatActivity
    {
        protected override void OnCreate(Bundle? savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            //below code is to set navigation bar and status bar color to Yellow
            if (Window is not null)
            {
                //<Color x:Key="Yellow">#E3AE09</Color>
                Window.SetStatusBarColor(Android.Graphics.Color.Rgb(227, 174, 9));
                Window.SetNavigationBarColor(Android.Graphics.Color.Rgb(227, 174, 9));
            }
        }       
    }
}

﻿
using System.ComponentModel;

namespace FaizMobileApp6
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(ListOfContentPage), typeof(ListOfContentPage));
            Routing.RegisterRoute(nameof(MainPage), typeof(MainPage));

        }

    }
}


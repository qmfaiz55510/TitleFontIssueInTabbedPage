﻿using FaizMobileApp6.Models;
using Microsoft.Maui.Controls.PlatformConfiguration;
using Microsoft.Maui.Platform;
using System.Collections.Generic;
using System.Diagnostics;


namespace FaizMobileApp6
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnProceedClicked(object sender, EventArgs e)
        {
            await Shell.Current.Navigation.PushAsync(new ListOfContentPage(), false);
        }
        protected override bool OnBackButtonPressed()
        {
            return true;
        }
    }

}


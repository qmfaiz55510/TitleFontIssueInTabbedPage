﻿
using FaizMobileApp6.Models;
using System.Xml;
using CommunityToolkit.Maui.Views;
using FaizMobileApp6.Views;
using CommunityToolkit.Maui.Alerts;

namespace FaizMobileApp6
{
    public partial class DisplayFullContentPage : ContentPage
    {
        public DisplayFullContentPage()
        {
            InitializeComponent();
        }
        private async void btnGoToTab_Clicked(object sender, EventArgs e)
        {
            var Popup = new GoToTabPopupView();
            var result = await this.ShowPopupAsync(Popup);
            int gototab = (int)(result ?? 0);
            if (gototab != 0)
                await Shell.Current.Navigation.PushModalAsync(new DisplayContentPage(), false);
        }
        private void btnShowTabContent_Clicked(object sender, EventArgs e)
        {
            Navigation.PushModalAsync(new DisplayContentPage(), false);
        }
        private void btnGoBack_Clicked(object sender, EventArgs e)
        {
            OnBackButtonPressed();
        }
        protected override bool OnBackButtonPressed()
        {
            Shell.Current.Navigation.PushAsync(new ListOfContentPage(), false);
            return true;
        }
    }
}
namespace FaizMobileApp6.Views;
using CommunityToolkit.Maui.Views;


public partial class GoToTabPopupView : Popup
{
    public GoToTabPopupView(int maxAyat = 1)
    {
        InitializeComponent();
    }
    private void OkButton_Clicked(object sender, EventArgs e)
    {
        Close(Convert.ToInt32(txtTabnumber.Text));
    }
    private async void CancelButton_Clicked(object sender, EventArgs e)
    {
        await CloseAsync(0);
    }


}